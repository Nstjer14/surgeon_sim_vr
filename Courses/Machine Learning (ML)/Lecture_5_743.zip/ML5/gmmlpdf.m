function l=gmmlpdf(varargin)
%GMMLPDF obsolete function - please use GAUSSMIXP instead
l=gaussmixp(varargin{1:nargin});
